
1. please use Synopsys Design Vision 2019 edition to synthesis.
    $ add synopsys2019
