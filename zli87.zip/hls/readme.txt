
 1. use Xilinx Vitis)HLS 2020.2 edition
 2. execute vitis_hls -f script.tcl
 3. open project and read hls report
