#include <iostream>
using namespace std;
#include <stdio.h>
#include <string.h>
#include <ap_int.h>

#define WORDSIZE 16 // bits per word
#define uint16 unsigned int
typedef ap_uint<1> bit;
typedef ap_uint<16> bit16;
typedef ap_uint<9> bit9;
typedef ap_uint<6> bit6;
typedef ap_uint<4> bit4;
typedef ap_uint<3> bit3;
typedef ap_uint<2> bit2;

void BNN( bit16 dim1, bit9 W, bit16* In, bit16* Out);
bit PE(bit9 W, bit9 A);
void printmatrix(bit** M, uint16 dim1, uint16 dim2);
