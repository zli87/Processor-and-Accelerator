#include "BNN.h"
#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <math.h>
using namespace std;

#define PRINT
uint16 string2uint(char* str){
	uint16 sum=0;
	for(int i=0;i< WORDSIZE;++i){
		if(str[15-i]-48) sum += pow(2,i);
		//printf("ggg %d %d \n",i,sum);
	}
	return sum;
}

void printmatrix(bit** M, uint16 dim1, uint16 dim2){
	for(int i=0;i<dim1;++i){
		for(int j=dim2-1;j>=0;--j){
			printf("%d ",(*M)[i*dim2+j]);
		}
		printf("[%d] \n",i);
	}
}

int main(){
	FILE * fpw = fopen("weight_sram.dat","r");
	FILE * fpi = fopen("input_sram.dat","r");
	FILE * fpo = fopen("golden_outputs.dat","r");

	char temp[WORDSIZE];
	char temp2[WORDSIZE];
	char *c[100];
	uint16 sizew;
	uint16 dim1,dim2,dim1o,dim2o;
	bit9 weight;
	bit16* input;
	bit16* output;
	bit16 *ans;
	bit16 tt1;

		fscanf(fpw, "%s %s", &c, &temp );
		sizew = string2uint(temp);
		printf("SIZE: %u\n",sizew);

		fscanf(fpw, "%s %s", &c, &temp );

		//weight = (bit16*)malloc(sizew*sizew*sizeof(bit16));
		for(int i=0;i<9;++i){
			weight[i] = temp[15-i]-48;
			cout<<weight[i];
		}
		cout<<endl;
		fscanf(fpi, "%s %s", &c, &temp );
		dim1 = string2uint(temp);
		cout<<"dim1: "<<dim1<<endl;
		fscanf(fpi, "%s %s", &c, &temp );
		dim2 = string2uint(temp);
		cout<<"dim2: "<<dim1<<endl;

		input = (bit16*)malloc(dim1*sizeof(bit16));
		sizew = 3;
		dim1o = dim1-sizew+1; // 14 = 16 -3 +1
		dim2o = 16-sizew+1;
		output = (bit16*)malloc(dim1o*sizeof(bit16));
		memset(output,'\0',dim1o*sizeof(bit16));
		ans = (bit16*)malloc(dim1o*sizeof(bit16));

		for(int i=0;i<dim1;++i){
			fscanf(fpi, "%s %d", &c, &tt1 );
			for(int j=0;j<16;++j){
				input[i][j] = (tt1[j]);
			}
		}
		for(int i=0;i<dim1o;++i){
			fscanf(fpo, "%s %s", &c, &temp2 );
			for(int j=0;j<16;++j){
				ans[i][j] = (bit)(temp2[15-j]-48);
			}
		}
		for(int i=0;i<dim1;++i){
				cout<<hex<<input[i];

			printf("[%u] \n",i);
		}
		cout<< "ans"<<endl;
		for(int i=0;i<dim1o;++i){
				cout<<hex<<ans[i];

			printf("[%u] \n",i);
		}
		//printf(" dim1 %u\n",dim1);
		//printf(" dim2 %u\n",dim2);

		BNN( dim1, weight, input, output);
#ifdef PRINT
			cout<<"output"<<endl;
			for(int i=0;i<dim1o;++i){
					cout<<hex<<output[i]<<" ";
				cout<<"["<<i<<"]"<<endl;
			}
#endif

		for(int i=0;i<dim1o;++i){
				if( output[i] != ans[i]){
					/*cout<<"===================================================\n";
					cout<<"ERROR at output["<<i<<"]["<<j<<"]="<<output[i*dim2o+j];
					cout<<", ans["<<i<<"]["<<j<<"]="<<ans[i*dim2o+j]<<endl;
					cout<<"===================================================\n";*/
#ifdef PRINT
					for(int i=0;i<dim1o;++i){
							cout<<hex<<ans[i]<<" ";
						cout<<"["<<i<<"]"<<endl;
					}
					exit(1);
#endif

			}
		}   //end for i
		printf("=====================================\n");
		printf("               PASS !!!\n");
		printf("=====================================\n");
		free(ans);
		free(output);
		free(input);
		//free(weight);

}
