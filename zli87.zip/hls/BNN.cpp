#include "BNN.h"
#define A(i) (bit9(bit6(bit3(p2(2+i,0+i)).concat(bit3(p1(2+i,0+i))))).concat(bit3(p0(2+i,0+i))))

void BNN(bit16 dim1, bit9 W, bit16* input, bit16* output){
#pragma HLS INTERFACE s_axilite port=return
#pragma HLS INTERFACE s_axilite port=dim1
#pragma HLS INTERFACE s_axilite port=weight
#pragma HLS INTERFACE s_axilite port=output
#pragma HLS INTERFACE m_axi depth=50 max_widen_bitwidth=32 port=input bundle=input_r
#pragma HLS INTERFACE m_axi depth=50 max_widen_bitwidth=32 port=output bundle=output_r

	bit4 dim1o = dim1-3+1 ;
	bit16 sram_input[16];
	bit16 sram_output[16];
	bit16 p0;
	bit16 p1;
	bit16 p2;
	bit2 dim;
	bit16 conv;

	dim[1] = dim1[4];
	dim[0] = dim1[2];

	loop_input: for(int i=0;i<16;++i){
		if(dim[1]){
			sram_input[i]= input[i];
		}else if(dim[0] & (i<12)){
			sram_input[i]= input[i];
		}else if(i<10){
			sram_input[i]= input[i];
		}
	}
	loop_conv :for(int i=0;i<dim1o+2;++i){
#pragma HLS pipeline II=1
		if(i<dim1){
			p0 = p1;
			p1 = p2;
			p2 = sram_input[i];
		}
		{

			conv[15]=0;
			conv[14]=0;
			conv[13]=(dim[1])? PE(W,A(13) ) : (bit)0;
			conv[12]=(dim[1])? PE(W,A(12) ) : (bit)0;
			conv[11]=(dim[1])? PE(W,A(11) ) : (bit)0;
			conv[10]=(dim[1])? PE(W,A(10) ) : (bit)0;
			conv[9]= (dim[1]|dim[0])? PE(W,A(9) ) : (bit)0;
			conv[8]= (dim[1]|dim[0])? PE(W,A(8) ): (bit)0;
			conv[7]= (dim[1]|dim[0])? PE(W,A(7) ): (bit)0;
			conv[6]= PE(W,A(6) );
			conv[5]= PE(W,A(5) );
			conv[4]= PE(W,A(4) );
			conv[3]= PE(W,A(3) );
			conv[2]= PE(W,A(2) );
			conv[1]= PE(W,A(1) );
			conv[0]= PE(W,A(0) );
		}
		if(i>=2){ // 14 2-15 2-11, 2-9
			sram_output[i-2] = conv;
		}
	}

	loop_output: for(int i=0;i<dim1o;++i){
		output[i] = sram_output[i];
	}
}
bit PE(bit9 W, bit9 A){
	bit9 conv = ~(W^A);
	bit4 sum = conv[0]+conv[1]+conv[2]+conv[3]+conv[4]+conv[5]+conv[6]+conv[7]+conv[8];
	bit Z = ((sum)>4);
	return Z;
}