
1. please use Synopsys Design Vision 2019 edition to synthesis.
    $ add synopsys2019

2. open ddc file and print report
    $ design_vision -no_gui
    $ read_ddc project.ddc
    $ source setup.tcl
    $ source Analyze.tcl
